Treasure Log press assets

Contents
- screenshots/: seven original full-resolution native iPhone screenshots (1206 x 2622 PNG)
- treasurelog-app-icon-1024.png: production Treasure Log app icon (1024 x 1024 PNG)
- brand/: approved existing Treasure Log website artwork in its original PNG dimensions

Demonstration data
The screenshots show a fictional collection created for editorial demonstration. Holdings and purchase costs are fictional. The Prices screen uses illustrative manual values for gold, silver, platinum, and copper; these are not current live market quotes. Copper is shown with its manual source label. Do not describe the pictured values as verified live prices.

Valuation context
Treasure Log estimates metal-content values from the selected reference and recorded holdings. Estimates are not appraisals, dealer offers, or numismatic valuations and do not include collectible premiums. The app's separate Copper HG reference is provisional: Gold API has not verified the physical unit or benchmark, the app interprets it as USD per avoirdupois pound, and the setting to include it in collection valuation is disabled by default.

All image files are supplied as captured or approved originals. No source code, project files, credentials, signing files, user data, or internal capture manifests are included.
